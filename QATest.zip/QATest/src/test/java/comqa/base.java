package comqa;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class base {
	
	WebDriver webdriver;
	

	//contrustor
	public  base (WebDriver webdriver) {
		this.webdriver = webdriver;
	}
	
	public WebDriver conexion() throws InterruptedException {
	//System.setProperty("webdriver.chromedriver.driver.", "./src/test/resources/drivers/chromedriver.exe");
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\josue catzim\\Documents\\chromedriver_win32\\chromedriver.exe");
		webdriver = new ChromeDriver();
			webdriver.manage().window().maximize();
			webdriver.manage().deleteAllCookies();
			
			return webdriver;
					
	}
	
	
	public void visit (String url) {
		webdriver.get(url);
	}
	
	public void click (By locator) {
		webdriver.findElement(locator).click();
		
	}
	public void type(By locator, String Text) {
		webdriver.findElement(locator).sendKeys(Text);
	}
	
	public String getText(WebElement element) {
	return element.getText();
	}
	
	


}
