package comqa;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class registro extends base {
	WebDriver  webdriver;
	
	//locator
	
	By registroLocator = By.linkText("REGISTER");
	By userLocator = By.name("email");
	By passLocator = By.name("password");
	By confirmLocator = By.xpath("//input[@name='confirmPassword']");
	By btnLocator = By.xpath("//input[@src='/images/forms/submit.gif']");
	By msgLocator = By.tagName("font");
			
	public registro (WebDriver webdriver) {
		super(webdriver);
	}
	
	public void registroUser() {
		click(registroLocator);
		type(userLocator, "test");
		type(passLocator, "test1");
		type(confirmLocator, "test1");
		click(btnLocator);
		
		
	}
	public String messageRegistro() {
		List<WebElement> fonts = webdriver.findElements(msgLocator);
						return getText(fonts.get(7));
	}

}
