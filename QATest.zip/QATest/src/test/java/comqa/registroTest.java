package comqa;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;

public class registroTest {
	
	WebDriver webdriver;
	registro registro;
	
	@Before
	public void setUp() throws Exception {
		registro = new registro(webdriver);
		webdriver = registro.conexion();
		
		registro.visit("http://newtours.demoaut.com/");
	}

	@After
	public void tearDown() throws Exception {
		//webdriver.quit();
	}

	@Test
	public void test() {
		registro.registroUser();  
		assertEquals("Note: Your user name is test", registro.messageRegistro());
		
		
	}

}
